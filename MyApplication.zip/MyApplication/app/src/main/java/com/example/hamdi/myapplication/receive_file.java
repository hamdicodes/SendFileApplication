package com.example.hamdi.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class receive_file extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_file);
    }
}
