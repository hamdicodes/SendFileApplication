package com.example.hamdi.myapplication;

public class FileEx {
    String isim;
    String yol;
    String uzanti;
    boolean klasorMu;
    public String getIsim() {
        return isim;
    }

    public void setIsim(String isim) {
        this.isim = isim;
    }

    public String getYol() {
        return yol;
    }

    public void setYol(String yol) {
        this.yol = yol;
    }

    public String getUzanti() {
        return uzanti;
    }

    public void setUzanti(String uzanti) {
        this.uzanti = uzanti;
    }

    public boolean isKlasorMu() {
        return klasorMu;
    }

    public void setKlasorMu(boolean klasorMu) {
        this.klasorMu = klasorMu;
    }

}
